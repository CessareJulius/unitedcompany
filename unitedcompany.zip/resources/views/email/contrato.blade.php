Han contratado los servicios de OfVir:

<p>
Nombre: {{ $name }}
</p>

<p>
{{ $email }}
</p>

<p>
{{ $phone }}
</p>

<p>
{{ $user_message }}
</p>