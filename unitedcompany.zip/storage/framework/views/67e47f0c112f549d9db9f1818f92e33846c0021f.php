<?php $__env->startSection('contenido'); ?>

    
  
    <?php if(Session::has('alert')): ?> 

        <div class="alert alert-<?php echo e(Session::get('alert')['tipo']); ?>" id="alert">
            <?php echo e(Session::get('alert')['mensaje']); ?>

        </div>
        <script>
            
        </script>
    <?php endif; ?>
    <h1>Lista de pagos</h1>

    <table class="table table-bordered table-condensed table-striped table-hover">
        <thead>
            <th>ID</th>
            <th>Usuario</th>
            <th>Razón de Pago</th>            
            <th>Fecha de Solicitud</th>
            <th>Fecha de pago</th>
            <th>Estado</th>
            <th>Acciones</th>
            
        </thead>
        <tbody>
            <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                <tr>
                    
                    <td><?php echo e($fila->id); ?></td>
                    <td><?php echo e($fila->user["user"]); ?></td>
                    <td><?php echo e($fila->razon_pago); ?></td>
                    
                    <td><?php echo e($fila->fecha_solicitud); ?></td>    
                    <td><?php echo e($fila->fecha_pago); ?></td>    
                    <td><b><?php echo e($status[$fila->status]); ?></b></td>
                    <td>
                        <?php if($fila->status==2): ?> <button onclick="$('#consignar-<?php echo e($fila->id); ?>').modal('show')" class="btn btn-primary">Revisar Consignación</button> <?php echo $__env->make('admin.payments.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> <?php endif; ?>
                        <?php if($fila->status==3): ?> <button onclick="$('#info-<?php echo e($fila->id); ?>').modal('show')" class="btn btn-primary">Ver</button>  <?php echo $__env->make('admin.payments.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> <?php endif; ?> 
                    </td>

                    
                    <td>
                        
                    </td>

                </tr>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>
    <?php $__env->startPush('scripts'); ?>
        <script>
            function pagopaypal(id) {
                alert('Luego de realizar el pago debe regresar acá para completar con el formulario de consignación');
                
                $("#cuenta_paypal-"+id).prop('name','cuenta_paypal');
                $("#pago-"+id).show();

            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app.clientarea', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>