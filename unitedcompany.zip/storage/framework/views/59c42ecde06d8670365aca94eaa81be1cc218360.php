
<div class="modal fade modal-slide-in-right" aria-hidden="true"
role="dialog" tabindex="-1" id="consignar-<?php echo e($fila->id); ?>">
	
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" 
				aria-label="Close">
                     <span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title">Consignar Pago</h4>
			</div>
			<div class="modal-body">
                
                <p>Razón de pago: <b><?php echo e($fila->razon_pago); ?></b></p>
                <p>Total: <b><?php echo e($fila->total); ?>$</b></p>
                
                <fieldset>
                    <legend>Medios de pago</legend>
                    <!--form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_blank">
                        
                        <input type="hidden" name="cmd" value="_xclick">
                        <input type="hidden" name="business" value="randygil_10@gmail.com">
                        <input type="hidden" name="lc" value="AL">
                        <input type="hidden" name="item_name" value="Suscripción de UnitedCompany">
                        <input type="hidden" name="item_number" value="1">
                        <input type="hidden" name="amount" value="<?php echo e($fila->total); ?>">
                        <input type="hidden" name="currency_code" value="USD">
                        <input type="hidden" name="button_subtype" value="services">
                        <input type="hidden" name="no_note" value="0">
                        <input type="hidden" name="tax_rate" value="0.000">
                        <input type="hidden" name="shipping" value="{$fila->total}}">
                        <input type="hidden" name="bn" value="PP-BuyNowBF:btn_buynowCC_LG.gif:NonHostedGuest">
                        <button type="submit" onclick="pagopaypal(<?php echo e($fila->id); ?>)" class="btn btn-primary">Pagar con Paypal</button>
                        <img alt="" border="0" src="https://www.paypalobjects.com/es_XC/i/scr/pixel.gif" width="1" height="1">
                    </form-->
                    <a type="submit" href="http://paypal.me/unitedcompany/<?php echo e($fila->total); ?>" target="_blank" onclick="pagopaypal(<?php echo e($fila->id); ?>)" class="btn btn-primary">Pagar con Paypal</a>

                    <div id="pago-<?php echo e($fila->id); ?>" style="display: none;">
                    <?php echo e(Form::open(['action'=>['clientarea\paymentController@store',$fila->id],'method'=>'post','class'=>'form-membresia'])); ?>

                        <div class="form-group">
                            <label for="">Cuenta de Paypal</label>
                            <input type="mail"  class="form-control" id="cuenta_paypal-<?php echo e($fila->id); ?>">
                        </div>
                        <button type="submit" class="btn btn-primary">Consignar pago</button>
                        
                    <?php echo e(Form::Close()); ?>

                    </div>
                </fieldset>
 
 
             
               
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
				<button type="submit" class="btn btn-primary">Confirmar</button>
			</div>
		</div>
	</div>
	
	
</div>