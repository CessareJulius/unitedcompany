
<div class="modal fade modal-slide-in-right" aria-hidden="true"
role="dialog" tabindex="-1" id="consignar-<?php echo e($fila->id); ?>">
	
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" 
				aria-label="Close">
                     <span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title">Consignar Pago</h4>
			</div>
			<div class="modal-body">
                
                <p>Razón de pago: <b><?php echo e($fila->razon_pago); ?></b></p>
                <p>Total: <b><?php echo e($fila->total); ?>$</b></p>
                
                <fieldset>
                    
                    <?php if($fila->paypal && $fila->status==2): ?>
                        <p>Fecha de confirmacion de pago: <strong><?php echo e("$fila->fecha_pago (". \Carbon\Carbon::parse($fila->fecha_pago)->diffForHumans().")"); ?></strong></p>
                        <p>Paypal suministrado: <strong><?php echo e($fila->paypal["cuenta"]); ?></strong></p>
                        <a href="<?php echo e(action('paymentController@confirmar',["id"=>$fila->id])); ?>" class="btn btn-primary">Confirmar Pago</a>
                    <?php endif; ?>

                </fieldset>
             
               
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
				<button type="submit" class="btn btn-primary">Confirmar</button>
			</div>
		</div>
	</div>	
</div>


<div class="modal fade modal-slide-in-right" aria-hidden="true"
role="dialog" tabindex="-1" id="info-<?php echo e($fila->id); ?>">
	
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" 
				aria-label="Close">
                     <span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title">Consignar Pago</h4>
			</div>
			<div class="modal-body">
                
                <p>Razón de pago: <b><?php echo e($fila->razon_pago); ?></b></p>
                <p>Total: <b><?php echo e($fila->total); ?>$</b></p>
                
                <fieldset>
                    
                   
					<p>Fecha de confirmacion de pago: <strong><?php echo e("$fila->fecha_pago (". \Carbon\Carbon::parse($fila->fecha_pago)->diffForHumans().")"); ?></strong></p>
					<p>Paypal suministrado: <strong><?php echo e($fila->paypal["cuenta"]); ?></strong></p>
					
                 
                </fieldset>
             
               
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
				<button type="submit" class="btn btn-primary">Confirmar</button>
			</div>
		</div>
	</div>	
</div>