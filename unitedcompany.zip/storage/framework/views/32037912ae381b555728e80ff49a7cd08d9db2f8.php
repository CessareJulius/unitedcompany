<?php $__env->startSection('contenido'); ?>   

        <?php if(Session::has('alert')): ?>
            <div class="alert alert-<?php echo e(Session::get('alert')['tipo']); ?>">
                <p><?php echo e(Session::get('alert')['mensaje']); ?></p>
            </div>
        <?php endif; ?>

        <div class="row">
            <?php echo Form::open(['url'=>'/clientes','method'=>'GET','autocomplete'=>'off','role'=>'search']);; ?>

                    <div class="col-sm-12">
                        <div class="form-group">
                            <div class="input-group">
                                <input type="text" name="buscar" class="form-control" placeholder="Buscar..." value="<?php echo e($buscar); ?>">
                                <span class="input-group-btn"><button class="btn btn-primary">Buscar</button></span>
                            </div>
                        </div>
                    </div>

                
            <?php echo Form::close(); ?>

        </div>
    
    <?php if(count($clientes) <1 && strlen($buscar)>0): ?>
    <h3>No se encontraron usuarios para <?php echo e($buscar); ?></h3>
    <?php else: ?>
    <?php if(strlen($buscar)>0): ?> <h3>Resultados de la búsqueda de: <?php echo e($buscar); ?></h3><?php endif; ?>
    <h1>Lista de Clientes <a href="<?php echo e(action('clienteController@create')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Agregar</a></h1>

    <table class="table table-responsive table-bordered table-condensed table-striped table-hover">
        <thead>
            <th>ID</th>
            <th>Usuario</th>
            <th>Nombres</th>
            <th>Apellidos</th>
            <th>DNI</th>
            <th>Fecha Nac</th>
            <th>Direccion</th>
            <th>Correo</th>
            <th>Telefono</th>
            <th>Membresía</th>
            <th>Acciones</th>
            
        </thead>
        <tbody>
            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                    <tr>
                    <td><?php echo e($fila->id); ?></td>
                    <td><?php echo e($fila->user); ?></td>
                    <td><?php echo e($fila->name); ?></td>
                    <td><?php echo e($fila->lastname); ?></td>
                    <td><?php echo e($fila->dni); ?></td>
                    <td><?php echo e($fila->birthday); ?></td>
                    <td><?php echo e($fila->address); ?></td>    
                    <td><?php echo e($fila->email); ?></td>    
                    <td><?php echo e($fila->phone); ?></td>    
                    <td><a href="#" onclick="$('#modal-membresia-<?php echo e($fila->id); ?>').modal('show')"><?php if(!$fila->membership): ?> Sin suscripción <?php else: ?> <?php echo e($membresias[$fila->membership["membership_id"]]); ?> <?php endif; ?></a></td> 
                    
                    <td>
                        <a class="btn btn-primary" href="<?php echo e(action('clienteController@edit',['id'=>$fila->id])); ?>">Editar</a>
                        <a class="btn btn-danger" onclick="$('#modal-delete-<?php echo e($fila->id); ?>').modal('show')">Eliminar</a>
                    </td>

                </tr>
                <?php echo $__env->make('admin.clientes.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>

    <div class="col-sm-12"><?php echo e($clientes->render()); ?></div>
    <?php endif; ?>
    <?php $__env->startPush('scripts'); ?> 
        <script>
            function extender(id) {
                if (!$("#extender-"+id).is(':visible')) {
                    $("#extender-"+id).toggle();

                    $("#btn-extender-"+id).removeClass('btn-primary').addClass('btn-danger').html(`Cancelar`);
                    
                    //$("#membresia-"+id).prop('disabled','true');
                    $("#extender-"+id).children('.form-group').children('input').prop('name','extender');
                    $("#membresia-"+id).prop('name','');
                    $("#cambiar-membresia-"+id).toggle();
                }else {
                    $("#btn-extender-"+id).removeClass('btn-danger').addClass('btn-primary').html(`Extender Suscripción`);
                    $("#extender-"+id).toggle();
                    $("#extender-"+id).children('.form-group').children('input').prop('name','');
                    $("#membresia-"+id).prop('name','membresia');
                    $("#cambiar-membresia-"+id).toggle();
                }
            }


           
        </script>
    <?php $__env->stopPush(); ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>