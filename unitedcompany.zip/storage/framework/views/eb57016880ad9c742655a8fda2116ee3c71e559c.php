<?php $__env->startSection('contenido'); ?>
    <div class="rodddw">
        <div class="pull-left">
            <a href="<?php echo e(route('clientarea.index')); ?>" class="btn btn-primary">Regresar</a>
        </div>
    </div>
    <div class="col-sm-4 col-sm-offset-3">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h4>Membresía Activa</h4>
            </div>

            <div class="panel-body">

            <p>Usted cuenta con la membresía <?php echo e($cliente->membership->membership["tipo"]); ?></p>
            <p>Suscripta desde el <strong> <?php echo e($cliente->membership->fecha_suscripcion); ?></strong></p>

            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app.clientarea', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>