<script>r=[];</script>
<div class="modal fade modal-slide-in-right" aria-hidden="true"
role="dialog" tabindex="-1" id="modal-delete-<?php echo e($fila->id); ?>">

	<?php echo e(Form::open(['action'=>['clienteController@destroy',$fila->id],'method'=>'delete','class'=>'form-membresia'])); ?>

	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" 
				aria-label="Close">
                     <span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title">Eliminar Cliente</h4>
			</div>
			<div class="modal-body">
				<p>¿Desea eliminar el cliente <?php echo e($fila->nombres); ?>?</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
				<button type="submit" class="btn btn-primary">Confirmar</button>
			</div>
		</div>
	</div>
	<?php echo e(Form::Close()); ?>


</div>

<div class="modal fade modal-slide-in-right" aria-hidden="true"
role="dialog" tabindex="-1" id="modal-membresia-<?php echo e($fila->id); ?>">
	<?php echo e(Form::open(['action'=>['clienteController@membresia',$fila->id],'method'=>'post'])); ?>

	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" 
				aria-label="Close">
                     <span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title">Editar Membresía</h4>
			</div>
			<div class="modal-body">
				<fieldset>
					<legend>Activar o cambiar membresía</legend>
					 <?php if(!$fila->membership): ?> 
					 	<p>Membresía actual: <b>Sin suscripción </b></p>
					 <?php else: ?> 
					    <p>Membresía actual: <b><?php echo e($membresias[$fila->membership["membership_id"]]); ?></b></p>
						<p>Estado: <b><?php echo e($fila->membership["status"]); ?></b></p>
						<p>Fecha de suscripción: <b><?php echo e($fila->membership["fecha_suscripcion"]); ?> (<?php echo e(\Carbon\Carbon::parse($fila->membership["fecha_suscripcion"])->diffForHumans()); ?>)</b></p>
						<p>Expiración: <b><?php echo e($fila->membership["expiration"]); ?> (<?php echo e(\Carbon\Carbon::parse($fila->membership["expiration"])->diffForHumans()); ?>)</b></p>
					<?php endif; ?>

					<div id="cambiar-membresia-<?php echo e($fila->id); ?>">
						<div class="form-group">
							<label for="">Cambiar membresía a:</label>
							<select name="membresia" id="membresia-<?php echo e($fila->id); ?>" class="form-control">
								<?php if(!$fila->membership): ?> <option value="0">NINGUNA</option><?php endif; ?>
								<?php $__currentLoopData = $m; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
									
									<option value="<?php echo e($l->id); ?>"  <?php if($fila->membership["membership_id"]==$l->id): ?> selected <?php endif; ?> ><?php echo e($membresias[$l->id]); ?></option>
									
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>

						<div class="form-group">
							<a href="<?php echo e(action('clienteController@suspenderMembresia',['id'=>$fila->id])); ?>" class="btn btn-warning">Suspender</a>
							<a href="<?php echo e(action('clienteController@eliminarMembresia',['id'=>$fila->id])); ?>" class="btn btn-danger">Eliminar</a>
						</div>

					</div>

					
					<?php if($fila->membership): ?> 

						<div class="">
							<a id="btn-extender-<?php echo e($fila->id); ?>" class="btn btn-primary" onclick="extender(<?php echo e($fila->id); ?>)">Extender Suscripción</a>
							<div id="extender-<?php echo e($fila->id); ?>" style="display: none;">
								<div class="form-group">
                            		<label for="">Días:</label>
                            		<input type="number" class="form-control" value="30">
                        		</div>
							</div>
							
						</div>

					<?php endif; ?>
				</fieldset>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
				<button type="submit" class="btn btn-primary">Confirmar</button>
			</div>
		</div>
	</div>
	<?php echo e(Form::Close()); ?>

	
</div>