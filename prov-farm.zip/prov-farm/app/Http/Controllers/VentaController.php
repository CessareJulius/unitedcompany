<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Carbon\Carbon;
use App\Farmacos;
use App\Inventario;
use App\Venta;
use App\DetalleVenta;
use PDF;
use Auth;
use App\Http\Controllers\FCMController;
class VentaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct() {
        $this->middleware('auth');
    }
    public function index(Request $request) {
        if (!Auth::user()->hasRole(['vendedor','root','gerente'])) {
            return redirect('/');
        }

        if ($request) {
            $query=trim($request->get('buscar'));
            $ventas = DB::table('venta')
            
            ->where('nro_factura','LIKE','%'.$query.'%')
            ->orderBy('id','asc')
            ->get();
        
        
            $cantidad = [];
            
            foreach($ventas as $ven) {
                $can = DB::table('detalle_venta')->select('count(id) as cantidad')->where('idventa','=',$ven->id)->count();
                $cantidad[$ven->id] = $can;
            }
        
            return view('venta.index',["ventas"=>$ventas,"buscar"=>$query,"cantidad"=>$cantidad]);
        }

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
          
        $nro=Venta::orderBy('nro_factura')->limit(1)->first();
        
        if (!isset($nro)) {
            $nro_factura=10000;
        }else {
            $nro_factura=$nro->nro_factura;
        }
        if (!Auth::user()->hasRole(['vendedor','root','gerente'])) {
            return redirect('/');
        }
        $farmacos = DB::table('inventario')->join('farmacos','inventario.idFarmacos','=','farmacos.id')->get();
        return view('venta.create',['farmacos'=>$farmacos,"nro_factura"=>$nro_factura+1]);


    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request){
        if (!Auth::user()->hasRole(['vendedor','root','gerente'])) {
            return redirect('/');
        }
       
        $this->validate($request,[
            'cedulacliente'=>'int|min:1|max:99999999|required',
            'nombrecliente'=>'required'
        ]);

        $nro=Venta::orderBy('nro_factura')->limit(1)->first();
                
        
        if (!isset($nro)) {
            $nro_factura=10000;
        }else {
            $nro_factura=$nro->nro_factura;
        }
        $venta = new Venta();
        $venta->nro_factura = $nro_factura+1;
        $venta->fecha_hora = Carbon::now();
        $venta->nombrecliente = $request->get('nombrecliente');
        $venta->cedulacliente = $request->get('cedulacliente');
        $venta->save();
        $total = 0;
        for ($i=0;$i<count($request->get('idfarmaco'));$i++) {
            
            
            $farmaco = $request->get('idfarmaco')[$i];
            $detalle = new DetalleVenta();
            $detalle->idfarmaco = $request->get('idfarmaco')[$i];
            $detalle->precio_venta = $request->get('precio_venta')[$i];
            $detalle->cantidad = $request->get('cantidad')[$i];
          
            $detalle->idventa = $venta->id;
            $detalle->save();

            $far = DB::table('inventario as i')->join('farmacos as f','f.id','=','i.idFarmacos')->where('idFarmacos','=',$request->get('idfarmaco')[$i])->first();
            
            if ($far->cantidad<1) {
                FCMController::notification('Medicamento Agotado',"El medicamento '$far->nombre' se ha agotado");
            }elseif ($far->cantidad<10) {
                FCMController::notification('Medicamento Casi Agotado',"El medicamento '$far->nombre' casi se agota");
            }
            
        
        }



        return redirect('venta');
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id){ 
        if (!Auth::user()->hasRole(['vendedor','root','gerente'])) {
            return redirect('/');
        }
        $venta = Venta::findOrFail($id);
        
        $detalleventa = DB::table('detalle_venta as dv')->join('farmacos as f','f.id','=','dv.idfarmaco')
        ->select('f.nombre','dv.cantidad','f.id','dv.precio_venta')
        ->where('dv.idventa','=',$id)
        ->get();
        $total=0;
        foreach($detalleventa as $de) {
            $total+= $de->precio_venta * $de->cantidad;
        }


        return view('venta.show',["venta"=>$venta,"detalleventa"=>$detalleventa,"total"=>$total]);
    }
    public function pdfDetalleVenta($id) {
        if (!Auth::user()->hasRole(['vendedor','root','gerente'])) {
            return redirect('/');
        }
    
        $venta = Venta::findOrFail($id);
        
        $detalleventa = DB::table('detalle_venta as dv')->join('farmacos as f','f.id','=','dv.idfarmaco')
        ->select('f.nombre','dv.cantidad','f.id','dv.precio_venta')
        ->where('dv.idventa','=',$id)
        ->get();
        $total=0;
        foreach($detalleventa as $de) {
            $total+= $de->precio_venta * $de->cantidad;
        }

      
        $data = ["venta"=>$venta,"detalleventa"=>$detalleventa,"total"=>$total];
        
        $view = \View::make('venta.pdfdetalleventa', compact('venta','detalleventa','total'))->render();
    
        $pdf = \App::make('dompdf.wrapper');
        $pdf->loadHTML($view);
        $pdf->setpaper('a4', 'portrait');
        return $pdf->stream('Venta-'.$id.'pdf');
       
        
    }

   
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id) {
        if (!Auth::user()->hasRole(['vendedor','root','gerente'])) {
            return redirect('/');
        }
        Ingreso::findOrFail($id)->delete();
        
        DetalleIngreso::where('idventa','=',$id)->delete();
        
        return redirect('venta');
    }
}
