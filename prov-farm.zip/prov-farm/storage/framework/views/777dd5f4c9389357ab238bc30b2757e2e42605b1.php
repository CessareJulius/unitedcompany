

<?php $__env->startSection('contenido'); ?>
    
    <div>
        <div class="col-sm-6 col-lg-6 col-md-6 col-xs-12">
            <h3>Crear nuevo fármaco</h3>
            <?php if(count($errors->all())>0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

        <?php echo Form::open(['url'=>'farmacos','method'=>'POST']); ?>

        <?php echo e(Form::token()); ?>


                
                
                <div class="form-group">
                    <div class="input-group">
                        <label for="nombre">Nombre</label><input type="text" value="<?php echo e(old('nombre')); ?>" class="form-control" placeholder="Nombre" name="nombre">
                    </div>
                </div>
            

                
                <div class="form-group">
                    <div class="input-group">
                        <label for="codigo">Código</label><input type="text" value="<?php echo e(old('codigo')); ?>" class="form-control" placeholder="Código" name="codigo">
                    </div>
                </div>
            

                
                
                <div class="form-group">
                    <div class="input-group">
                        <label for="presentacion">Presentación</label><input type="text" value="<?php echo e(old('presentacion')); ?>" class="form-control" placeholder="Presentacion" name="presentacion">
                    </div>
                </div>
            

                

                
                <button type="submit" class="btn btn-primary">Agregar</button>
                
                <a href="<?php echo e(url('farmacos')); ?>" class="btn btn-danger">Regresar</a>
            </div>

                
            
        <?php echo Form::close(); ?>


        </div>
    </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>