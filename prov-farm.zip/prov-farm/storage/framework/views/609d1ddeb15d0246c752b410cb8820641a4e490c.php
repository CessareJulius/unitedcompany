

<?php $__env->startSection('contenido'); ?>


    <div class="container">
        <div class="row">
            <?php echo Form::open(['url'=>'/farmacos','method'=>'GET','autocomplete'=>'off','role'=>'search']);; ?>

                    <div class="col-sm-11">
                        <div class="form-group">
                            <div class="input-group">
                                <input type="text" name="buscar" class="form-control" placeholder="Buscar Ej: Atamel" value="<?php echo e($buscar); ?>">
                                <span class="input-group-btn"><button class="btn btn-primary">Buscar</button></span>
                            </div>
                        </div>
                    </div>

                
            <?php echo Form::close(); ?>

        </div>
    </div>
    
    <?php if(count($farmacos) <1 && strlen($buscar)>0): ?>
    <h3>No se encontraron artículos para <?php echo e($buscar); ?></h3>
    <?php else: ?>
    <?php if(strlen($buscar)>0): ?> <h3>Resultados de la búsqueda de: <?php echo e($buscar); ?></h3><?php endif; ?>
    <h1>Lista de Fármacos <a href="<?php echo e(action('FarmacosController@create')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Agregar</a></h1>

    <table class="table table-bordered table-condensed table-striped table-hover">
        <thead>
            <th>ID</th>
            <th>Nombre</th>
            <th>Presentación</th>
            <th>Código</th>
            
            <th>Acciones</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $farmacos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                <tr>
                    <td><?php echo e($fila->id); ?></td>
                    <td><?php echo e($fila->nombre); ?></td>
                    <td><?php echo e($fila->presentacion); ?></td>
                    <td><?php echo e($fila->codigo); ?></td>
                    
                    <td>
                        <a class="btn btn-primary" href="<?php echo e(action('FarmacosController@edit',['id'=>$fila->id])); ?>">Editar</a>
                        <a class="btn btn-danger" onclick="$('#modal-delete-<?php echo e($fila->id); ?>').modal('show')">Eliminar</a>
                    </td>

                </tr>

                <?php echo $__env->make('farmacos.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>

    <div class="col-sm-12"><?php echo e($farmacos->render()); ?></div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>