

<?php $__env->startSection('contenido'); ?>


    <div class="container">
        <div class="row">
            <?php echo Form::open(['url'=>'/inventario','method'=>'GET','autocomplete'=>'off','role'=>'search']);; ?>

                    <div class="col-sm-11">
                        <div class="form-group">
                            <div class="input-group">
                                <input type="text" name="buscar" class="form-control" placeholder="Buscar Ej: Atamel" value="<?php echo e($buscar); ?>">
                                <span class="input-group-btn"><button class="btn btn-primary">Buscar</button></span>
                            </div>
                        </div>
                    </div>

                
            <?php echo Form::close(); ?>

        </div>
    </div>
    
    <?php if(count($inventario) <1 && strlen($buscar)>0): ?>
    <h3>No se encontraron artículos para <?php echo e($buscar); ?></h3>
    <?php else: ?>
    <?php if(strlen($buscar)>0): ?> <h3>Resultados de la búsqueda de: <?php echo e($buscar); ?></h3><?php endif; ?>
    <h1>Inventario de Fármacos <a href="<?php echo e(action('InventarioController@create')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Agregar</a></h1>

    <table class="table table-bordered table-condensed table-striped table-hover">
        <thead>
            <th>ID</th>
            <th>Nombre</th>
            <th>Código</th>
            <th>Presentación</th>
            <th>Cantidad</th>
            <th>Precio Venta</th>
            <th>Precio compra</th>
            <th>Acciones</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $inventario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                <tr>
                    <td><?php echo e($fila->id); ?></td>
                    <td><?php echo e($fila->nombre); ?></td>
                    <td><?php echo e($fila->codigo); ?></td>
                    <td><?php echo e($fila->presentacion); ?></td>
                    <td><?php echo e($fila->cantidad); ?></td>
                    <td><?php echo e($fila->precio_venta); ?></td>
                    <td><?php echo e($fila->precio_compra); ?></td>
                    
                    <td>
                        <a class="btn btn-primary" href="<?php echo e(action('InventarioController@edit',['id'=>$fila->id])); ?>">Editar</a>
                        <a class="btn btn-danger" onclick="$('#modal-delete-<?php echo e($fila->id); ?>').modal('show')">Eliminar</a>
                    </td>

                </tr>

                <?php echo $__env->make('inventario.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>