

<?php $__env->startSection('contenido'); ?>
    
    <div>
        <div class="col-sm-6 col-lg-6 col-md-6 col-xs-12">
            <h3>Crear nuevo usuario</h3>
            <?php if(count($errors->all())>0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

        <?php echo Form::open(['method'=>'POST','url'=>'users']); ?>

        <?php echo e(Form::token()); ?>


                
                
                <div class="form-group">
                    <div class="input-group">
                        <label for="name">Nombre</label><input type="text" value="<?php echo e(old('name')); ?>" class="form-control" placeholder="Nombre" name="name">
                    </div>
                </div>
            
                   
                <div class="form-group">
                    <div class="input-group">
                        <label for="user">Usuario</label><input type="text" value="<?php echo e(old('user')); ?>" class="form-control" placeholder="Usuario" name="user">
                    </div>
                </div>
                
                <div class="form-group">
                    <div class="input-group">
                        <label for="correo">Correo</label><input type="text" value="<?php echo e(old('email')); ?>" class="form-control" placeholder="Correo" name="email">
                    </div>
                </div>
            

                
                
                <div class="form-group">
                    <div class="input-group">
                        <label for="password">Contraseña</label><input type="password" value="<?php echo e(old('password')); ?>" class="form-control" placeholder="Contraseña" name="password">
                    </div>
                </div>

                 <div class="form-group">
                    <div class="input-group">
                        <label for="password-confirm">Confirmar Contraseña</label><input id="password-confirm" type="password" class="form-control" name="password_confirmation" placeholder="Confirmar Contraseña" required>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <label for="tipo">Tipo de Usuario: </label>
                        <select name="tipo" id="" class="form-control">
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <option value="<?php echo e($role->id); ?>"><?php echo e($role->display_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                        </select>

                    </div>
                </div>
            

                

                
                <button type="submit" class="btn btn-primary">Agregar</button>
                
                <a href="<?php echo e(url('users')); ?>" class="btn btn-danger">Regresar</a>
            </div>

                
            
        <?php echo Form::close(); ?>


        </div>
    </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>