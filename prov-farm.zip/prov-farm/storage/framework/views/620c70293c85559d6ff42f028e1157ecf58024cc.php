<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    
     <!-- Bootstrap 3.3.5 -->
    
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
  

    <title>Inventario de Medicamentos</title>
</head>
<body>

        <p style="float: right;">Fecha: <?php echo e(Carbon\Carbon::now()); ?></p>
        <h1 style="text-align: center">Inventario General de Fármacos</h1>
        <h5>Total de fármacos: <?php echo e(count($inventario)); ?></h5>
         <table >   
            <thead style="background-color: #3C8DBC; color: white;">
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Código</th>
                <th>Presentación</th>
                <th>Cantidad</th>
                <th>Precio Venta</th>
                <th>Precio compra</th>
            </tr>
          </thead>
        <tbody>
            <?php $__currentLoopData = $inventario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                <tr>
                    <td><?php echo e($fila->id); ?></td>
                    <td><?php echo e($fila->nombre); ?></td>
                    <td><?php echo e($fila->codigo); ?></td>
                    <td><?php echo e($fila->presentacion); ?></td>
                    <td><?php echo e($fila->cantidad); ?></td>
                    <td><?php echo e($fila->precio_venta); ?></td>
                    <td><?php echo e($fila->precio_compra); ?></td>
                    
                  

                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>
               
<style>

thead:before, thead:after { display: none; }
tbody:before, tbody:after { display: none; }
body {
  font-family: 'Source Sans Pro',sans-serif;
  
}
table {
page-break-inside: auto;
  width: 100%;
  margin-top: 20px;
  
}
table tr {
  
  text-align: center;
  
}
table tbody tr {
  height: 40px;
}
table tbody tr:nth-child(2n+1) {
  background-color: lightgray;
}
table tfoot {
   background-color: #3C8DBC;
  color: white;
}

</style>

    
</body>
</html>