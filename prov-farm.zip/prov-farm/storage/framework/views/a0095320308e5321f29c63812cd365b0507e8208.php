

<?php $__env->startSection('contenido'); ?>
    
    <div>
        <div class="col-sm-12 col-lg-12 col-md-12 col-xs-12">
            <h3>Editar fármaco al inventario</h3>
            <?php if(count($errors->all())>0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

        <?php echo Form::open(['method'=>'PATCH','url'=>['inventario',$inventario->id]]); ?>

        
                <div class="col-sm-12">
                    <div class="form-group">
                        <label for="farmaco">Código</label>                        
                        <select name="farmaco" id="" class="selectpicker showtick showmenuarrow" data-live-search="true" data-width="100%" disabled>
                            
                                <option value="<?php echo e($inventario->id); ?>" selected>[<?php echo e($inventario->codigo); ?>] <?php echo e($inventario->nombre); ?> <?php echo e($inventario->presentacion); ?></option>
                            

                        </select>
                        
                    </div>
                </div>
            

                <div class="form-group">
                    <label for="cantidad">Cantidad</label><input type="number" value="<?php echo e($inventario->cantidad); ?>" class="form-control" placeholder="Cantidad" name="cantidad">
                    
                </div>

                <div class="form-group">
                    <label for="precio_venta">Precio Venta</label><input type="number" value="<?php echo e($inventario->precio_venta); ?>" class="form-control" placeholder="Precio de venta" name="precio_venta">
                    
                </div>  

                <div class="form-group">
                    <label for="precio-compra">Precio Compra</label><input type="number" value="<?php echo e($inventario->precio_venta); ?>" class="form-control" placeholder="Precio de venta" name="precio_compra">
                    
                </div>  

                


                <button type="submit" class="btn btn-primary">Editar</button>               
                <a href="<?php echo e(url('inventario')); ?>" class="btn btn-danger">Regresar</a>
            </div>
            
        <?php echo Form::close(); ?>


        </div>
    </div>


    <?php $__env->startPush('scripts'); ?>
        <script src="<?php echo e(asset('js/bootstrap-select.min.js')); ?>"></script>
        <script>
        $('.selectpicker').selectpicker({
            style: 'btn-info',
            size: 4
        });
</script>
    <?php $__env->stopPush(); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>